# Gstuds: Estudos para concurso
Criado por Guilherme Augusto Porto Silva.

Site estático (HTML + CSS + JavaScript puro) instalável como app (PWA). Não precisa de build, Node ou instalação.

## Arquivos
- `index.html` – estrutura da página
- `styles.css` – design
- `app.js` – funcionalidades, disciplinas e conteúdos
- `manifest.webmanifest` – dados do app (nome, ícones, cores)
- `sw.js` – service worker (funciona offline depois do primeiro acesso)
- `icons/` – ícones do app
- `vercel.json` – configuração da Vercel

## Publicar na Vercel (grátis)
1. Crie um repositório no GitHub e envie TODO o conteúdo desta pasta (arrastando os arquivos em "Add file > Upload files").
2. Em vercel.com, entre com o GitHub, clique em "Add New > Project", escolha o repositório.
3. Em "Framework Preset" deixe **Other**. Não preencha build nem output. Clique em **Deploy**.
4. A Vercel mostra o seu link (ex.: `seu-projeto.vercel.app`).

## Instalar no iPhone
1. Abra o link no **Safari** (precisa ser o Safari).
2. Toque no botão de compartilhar e em **Adicionar à Tela de Início**.
3. Toque em **Adicionar**. O ícone "Gstuds" aparece como app.

## Observações
- Seu progresso é salvo no próprio aparelho (localStorage). O app instalado na tela inicial e o Safari podem guardar dados separados no iPhone. Sincronizar entre aparelhos exige um banco de dados (Supabase), planejado para depois.
- Nada depende do Claude. Só a fonte Plus Jakarta Sans vem do Google Fonts; sem internet o app usa a fonte do sistema.
- Para atualizar o site: troque os arquivos no GitHub e a Vercel republica sozinha. Se o iPhone mostrar a versão antiga, aumente o número em `CACHE = "gstuds-v1"` no `sw.js` (ex.: `gstuds-v2`).
